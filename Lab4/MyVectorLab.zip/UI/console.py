from Domain.MyVector import MyVector
from Domain.Validator import VectorValidator
from Repository.repo import VectorRepository


class Console:
    def __init__(self, list_of_vectors: VectorRepository):
        self.__list_of_vectors = list_of_vectors

    def read_the_list(self):
        list1 = []
        element = input("Introduce a value for the list: ")
        while element != "":
            list1.append(int(element))
            element = input("Introduce a value for the list: ")
        return list1

    def read_vector(self):
        try:
            name_id = input("name_id= ")
            colour = input("colour= ")
            vector_type = int(input("vector_type= "))
            values = self.read_the_list()
            vector = MyVector(name_id, colour, vector_type, values)
            return vector
        except ValueError as ve:
            print("Introduce valid data!", ve)
        except IndexError as ie:
            print("Introduce a valid index!", ie)
        except Exception as e:
            print("Error!", e)

    def print_menu(self):
        print("1. Add a vector to the repository")
        print("2. Get all vectors")
        print("3. Get a vector at a given index")
        print("4. Update a vector at a given index")
        print("5. Update a vector identified by name_id")
        print("6. Delete a vector by index")
        print("7. Delete a vector by name_id")
        print("8. Plot all vectors in a chart based on the type and colour of each vector")
        print("9. Get the vector which represents the sum of all vectors")
        print("10. Get the list of vectors having the minimum less than a given value.")

    def run_console(self):
        while True:
            self.print_menu()
            option = int(input("Introduce the option: "))
            if option == 1:
                vector = self.read_vector()
                self.__list_of_vectors.add_a_vector(vector)
            elif option == 2:
                vectors_storage = self.__list_of_vectors.get_all_vectors()
                for vector in vectors_storage:
                    print(vector, end=";")
                print()
            elif option == 11:
                break
            else:

                print("Option is invalid ! The end!")
