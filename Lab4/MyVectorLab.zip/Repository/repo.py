import matplotlib.pyplot as plt
from Domain.MyVector import MyVector
from Domain.Validator import VectorValidator


class VectorRepository:
    '''
    A vector repository is a structure that manages multiple vectors of class MyVector
    '''

    def __init__(self, validator: VectorValidator):
        '''
        Create a new instance of VectorRepository
        '''
        self.__data_storage = []
        self.__validator = validator

    def add_a_vector(self, vector: MyVector):
        '''
        add a new vector in the list
        :param vector:
        :return:
        '''

        ok = 1
        for vec in self.__data_storage:
            if vec.get_name_id() == vector.get_name_id():
                ok = 0
        if ok == 0:
            raise ValueError(f"The vector with the name_id {vector.get_name_id()} already exists!")
        # self.__validator.validate_vector(vector)
        self.__data_storage.append(vector)

    def get_all_vectors(self):
        '''
        it returns all vectors from list
        :return:
        '''
        return self.__data_storage

    def get_a_vector_at_an_index(self, index):
        '''
        it returns an element from an given index from list
        :param index:
        :return:
        '''
        if index < 0 or index > len(self.__data_storage) - 1:
            raise IndexError("There is no vector corresponding to the given index.")

        return self.__data_storage[index]

    def update_a_vector(self, index, new_colour, new_vector_type, new_values):
        '''
        Update a vector
        :param index:
        :param new_colour:
        :param new_vector_type:
        :param new_values:
        :return:
        '''
        if index < 0 or index > len(self.__data_storage) - 1:
            raise IndexError("There is no vector corresponding to the given index.")
        self.__validator.validate_vector(self.__data_storage[index])
        self.__data_storage[index].set_colour(new_colour)
        self.__data_storage[index].set_vector_type(new_vector_type)
        self.__data_storage[index].set_values(new_values)

    def update_a_vector_by_name(self, name_id, new_colour, new_vector_type, new_values):
        '''
        it updates vector by unique attribute name_id
        :param name_id:
        :param new_colour:
        :param new_vector_type:
        :param new_values:
        :return:
        '''
        for elem in self.__data_storage:
            if elem.get_name_id() == name_id:
                elem.set_colour(new_colour)
                elem.set_vector_type(new_vector_type)
                elem.set_values(new_values)
                self.__validator.validate_vector(elem)

    def delete_a_vector_by_index(self, index):
        '''
        delete a vector by a given index
        :param index:
        :return:
        '''
        if index < 0 or index > len(self.__data_storage) - 1:
            raise IndexError("There is no vector corresponding to the given index.")
        del self.__data_storage[index]

    def delete_a_vector_by_name(self, name_id):
        '''
        delete vector by name
        :param name_id:
        :param vector:
        :return:
        '''

        for elem in range(len(self.__data_storage) - 1, -1, -1):
            if self.__data_storage[elem].get_name() == name_id:
                del self.__data_storage[elem]

    def plot_vectors(self):

        '''
        '''
        pass

    def get_the_sum_of_all_vectors(self):
        '''
        Get the vector which represents the sum of all vectors
        :return:
        '''
        s = 0
        s2 = 0
        if len(self.__data_storage) == 0:
            raise ValueError("The list should contain elements")
        if len(self.__data_storage) == 1:
            return self.__data_storage[0].get_values().sum_of_array()
        if len(self.__data_storage) == 2:
            s = self.__data_storage[0].get_values.sum_of_array() + self.__data_storage[1].get_values.sum_of_array()
            return s
        for elem in range(2, len(self.__data_storage)):
            s2 += self.__data_storage[elem].get_values().sum_of_array()
        return s2

    def get_the_list_of_vector_with_minimum_elements(self, given_min):
        '''
        Return the list of vectors having the minimum less than a given value.
        :param given_min:
        :return:
        '''
        if len(self.__data_storage) == 0:
            raise ValueError("The list shoud not be empty")
        for elem in range(len(self.__data_storage) - 1, -1, -1):
            if self.__data_storage[elem].minim_of_array() >= given_min:
                del (self.__data_storage[elem])
        return self.__data_storage
