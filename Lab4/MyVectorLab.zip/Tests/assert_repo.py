import unittest
from Domain.MyVector import MyVector
from Domain.Validator import VectorValidator
from Repository.repo import VectorRepository

class TestRepo(unittest.TestCase):
    def setUp(self):
        unittest.TestCase.setUp(self)
        self.v = MyVector(2, "m", 22, [40, 53, 41])
        self.v2 = MyVector(1, "m", 4, [22, 33, 2])
        self.v3 = MyVector(55, "r", 10, [30, 40, 20, 50])
        self.v4 = MyVector(3, "m", 10, [30, 40, 20, 50])
        self.v5 = MyVector(7, "g", 15, [2])
        self.v6 = MyVector(9, "y", 4, [5])
        self.v7 = MyVector(11, "y", 4, [])
        self.v8 = MyVector(22, "y", 4, [10, 20, 30])
        self.v9 = MyVector(13, "m", 445, [])
        self.v10 = MyVector(100, "y", 3, [])
        self.v11 = MyVector(100, "y", 3, [25,26])
        self.list_validator=VectorValidator()
        self.list_validator2=VectorValidator()
        self.list_validator3 = VectorValidator()
        self.list_validator4 = VectorValidator()
        self.list_validator5 = VectorValidator()
        self.list_validator6 = VectorValidator()
        self.list_of_vectors7 = VectorValidator()

        self.list_of_vectors = VectorRepository(self.list_validator)
        self.list_of_vectors2 = VectorRepository(self.list_validator2)
        self.list_of_vectors3 = VectorRepository(self.list_validator3)
        self.list_of_vectors4 = VectorRepository(self.list_validator4)
        self.list_of_vectors5 = VectorRepository(self.list_validator5)
        self.list_of_vectors6 = VectorRepository(self.list_validator6)

        self.list_of_vectors.add_a_vector(self.v)
        self.list_of_vectors.add_a_vector(self.v2)
        self.list_of_vectors.add_a_vector(self.v3)
        self.list_of_vectors2.add_a_vector(self.v4)
        self.list_of_vectors3.add_a_vector(self.v6)
        self.list_of_vectors4.add_a_vector(self.v8)
        self.list_of_vectors4.add_a_vector(self.v9)
        self.list_of_vectors4.add_a_vector(self.v10)
        self.list_of_vectors5.add_a_vector(self.v)
        self.list_of_vectors5.add_a_vector(self.v2)
        self.list_of_vectors6.add_a_vector(self.v3)
        self.list_of_vectors6.add_a_vector(self.v4)

        self.mylist=[]
        self.mylist1=[]
        self.result=self.list_of_vectors.get_all_vectors()
        self.result2 = self.list_of_vectors2.get_all_vectors()

    def tearDown(self):
        unittest.TestCase.tearDown(self)

    def test_get_all_vectors(self):
        self.assertEqual(len(self.result),3)
        self.assertEqual(len(self.result2),1)
        self.assertEqual(len(self.list_of_vectors3.get_all_vectors()),1)
        self.assertEqual(len(self.list_of_vectors4.get_all_vectors()), 3)
        self.assertEqual(len(self.list_of_vectors5.get_all_vectors()),2)
    def test_get_a_vector_at_an_index(self):
        self.assertRaises(IndexError,self.list_of_vectors2.get_a_vector_at_an_index,-5)
        self.assertIsNotNone(self.list_of_vectors2.get_a_vector_at_an_index(0))
        self.assertIsNotNone(self.list_of_vectors4.get_a_vector_at_an_index(1))
        self.assertIsNotNone(self.list_of_vectors4.get_a_vector_at_an_index(2))
        self.assertIsNotNone(self.list_of_vectors5.get_a_vector_at_an_index(1))
    def test_update_a_vector(self):
        self.list_of_vectors4.update_a_vector(1,"r",2,[1])
        self.mylist=self.list_of_vectors4.get_all_vectors()
        self.assertEqual(self.mylist[1].get_colour(),"r")
        self.assertEqual(self.mylist[1].get_vector_type(),2)
        self.assertEqual(self.mylist[1].get_values(),[1])
        self.assertEqual(self.mylist[1].get_name_id(),13)
        self.assertIsNotNone(self.mylist[1])
    def test_get_the_list_of_vector_with_minimum_elements(self):
        self.assertEqual(len(self.list_of_vectors.get_the_list_of_vector_with_minimum_elements(4)),1)
        self.assertRaises(IndexError,self.list_of_vectors4.get_the_list_of_vector_with_minimum_elements,47)
        self.assertRaises(IndexError, self.list_of_vectors4.get_the_list_of_vector_with_minimum_elements, 25)
        self.assertEqual(len(self.list_of_vectors2.get_the_list_of_vector_with_minimum_elements(433)),1)
        self.assertEqual(len(self.list_of_vectors2.get_the_list_of_vector_with_minimum_elements(0)), 0)




if __name__ == "__main__":
    unittest.main()



