from Domain.Validator import VectorValidator
from Repository.repo import VectorRepository
from UI.console import Console

def main():
    v = VectorValidator()
    l = VectorRepository(v)
    cons = Console(l)
    cons.run_console()

main()